import numpy as np

np.testing.bob  # E: Module has no attribute
np.bob  # E: Module has no attribute