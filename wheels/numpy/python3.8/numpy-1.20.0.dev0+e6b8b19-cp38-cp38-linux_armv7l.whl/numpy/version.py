
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.20.0'
version = '1.20.0'
full_version = '1.20.0.dev0+e6b8b19'
git_revision = 'e6b8b19ee832ae89289721301a4f5afcd454ec4f'
release = False

if not release:
    version = full_version
